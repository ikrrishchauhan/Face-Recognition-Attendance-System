num=int(input("Enter the number:"))
if num==0 or num==1:
    print(num,"Not a prime number")
elif(num>1):
    for i in range(2,num):
     if(num%i==0):
        print(num," Not a Prime number")
        break
    else:
        print(num,"prime number")


    



