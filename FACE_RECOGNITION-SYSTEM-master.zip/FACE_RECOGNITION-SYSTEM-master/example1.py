# r=5
# for i in range(1,6):
#     for j in range(1,6):
#         print("*", end=" ")
#     print()

# r=5
# for i in range(1,r+1):
#     for j in range(1,i+1):
#         print("*",end=" ")
#     print()

# n=5
# for i in range(n,0,-1):
#     for j in range(i):
#         print("*",end=" ")
#     print()
        
# n=6
# for i in range(1,6):
#     for j in range(1,i+1):
#         print(j,end=" ")
#     print()

n=5
for i in range(n,0,-1):
    for j in range(i,0,-1):
        print(j,end=" ")
    print()